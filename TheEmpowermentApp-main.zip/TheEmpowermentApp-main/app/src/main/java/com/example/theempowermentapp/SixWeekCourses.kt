package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class SixWeekCourses : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_six_week_courses)
        val monthButton: Button = findViewById(R.id.monthcourseBtn2)
        monthButton.setOnClickListener {
            val intent = Intent(this, SixMonthCourses::class.java)
            startActivity(intent)
        }
        val backButton: Button = findViewById(R.id.backBtn4)
        backButton.setOnClickListener {
            finish()
        }
        val descriptionButton: Button = findViewById(R.id.descriptionBtn2)
        descriptionButton.setOnClickListener {
            val intent = Intent(this, FirstAidDescription::class.java)
            startActivity(intent)
        }
    }
}
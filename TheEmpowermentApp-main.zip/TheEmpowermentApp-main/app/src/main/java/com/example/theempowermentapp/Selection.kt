package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class Selection : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_selection)

        val courseSelectionButton: Button = findViewById(R.id.backToCourseSelectionBtn)
        courseSelectionButton.setOnClickListener {
            val intent = Intent(this, CourseSelection::class.java)
            startActivity(intent)
        }

        val checkoutButton: Button = findViewById(R.id.checkoutBtn)
        checkoutButton.setOnClickListener {
            val intent = Intent(this, Checkout::class.java)

            // Get the state of the checkboxes
            val firstAid = findViewById<CheckBox>(R.id.firstAid).isChecked
            val sewing = findViewById<CheckBox>(R.id.sewing).isChecked
            val landscaping = findViewById<CheckBox>(R.id.landScaping).isChecked
            val lifeSkills = findViewById<CheckBox>(R.id.lifeSkills).isChecked
            val childMinding = findViewById<CheckBox>(R.id.childMinding).isChecked
            val cooking = findViewById<CheckBox>(R.id.cooking).isChecked
            val gardenMaintenance = findViewById<CheckBox>(R.id.gardenMaintenance).isChecked

            // Pass selected course info
            intent.putExtra("firstAid", firstAid)
            intent.putExtra("sewing", sewing)
            intent.putExtra("landscaping", landscaping)
            intent.putExtra("lifeSkills", lifeSkills)
            intent.putExtra("childMinding", childMinding)
            intent.putExtra("cooking", cooking)
            intent.putExtra("gardenMaintenance", gardenMaintenance)

            startActivity(intent)
        }
    }
}

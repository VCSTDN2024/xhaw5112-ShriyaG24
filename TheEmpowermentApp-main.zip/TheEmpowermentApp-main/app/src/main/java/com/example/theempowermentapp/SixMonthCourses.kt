package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SixMonthCourses : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_six_month_courses)
        val weekButton: Button = findViewById(R.id.weekcourseBtn2)
        weekButton.setOnClickListener {
            val intent = Intent(this, SixWeekCourses::class.java)
            startActivity(intent)
        }
        val backButton: Button = findViewById(R.id.backBtn3)
        backButton.setOnClickListener {
            finish()
        }
        val descriptionButton: Button = findViewById(R.id.descriptionBtn)
        descriptionButton.setOnClickListener {
            val intent = Intent(this, FirstAidDescription::class.java)
            startActivity(intent)
        }
    }
}
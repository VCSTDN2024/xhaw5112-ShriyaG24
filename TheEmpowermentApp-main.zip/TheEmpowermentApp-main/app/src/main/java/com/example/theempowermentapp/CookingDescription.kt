package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CookingDescription : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cooking_description)
        val nextButton: Button = findViewById(R.id.nxtBtn6)
        nextButton.setOnClickListener {
            val intent = Intent(this, GardenMaintenanceDescription::class.java)
            startActivity(intent)
        }
        val courseSelectionButton: Button = findViewById(R.id.backtoselectionBtn3)
        courseSelectionButton.setOnClickListener {
            val intent = Intent(this, CourseSelection::class.java)
            startActivity(intent)
        }
    }
}
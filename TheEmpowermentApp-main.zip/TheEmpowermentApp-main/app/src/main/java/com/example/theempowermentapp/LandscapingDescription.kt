package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class LandscapingDescription : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_landscaping_description)
        val nextButton: Button = findViewById(R.id.nxtBtn4)
        nextButton.setOnClickListener {
            val intent = Intent(this, LifeSkillsDescription::class.java)
            startActivity(intent)
        }
        val courseSelectionButton: Button = findViewById(R.id.backtoselectionBtn6)
        courseSelectionButton.setOnClickListener {
            val intent = Intent(this, CourseSelection::class.java)
            startActivity(intent)
        }
    }
}
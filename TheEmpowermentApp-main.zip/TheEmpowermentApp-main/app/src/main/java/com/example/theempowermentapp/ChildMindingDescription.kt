package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ChildMindingDescription : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_child_minding_description)
        val nextButton: Button = findViewById(R.id.nxtBtn5)
        nextButton.setOnClickListener {
            val intent = Intent(this, CookingDescription::class.java)
            startActivity(intent)
        }
        val courseSelectionButton: Button = findViewById(R.id.backtoselectionBtn4)
        courseSelectionButton.setOnClickListener {
            val intent = Intent(this, CourseSelection::class.java)
            startActivity(intent)
        }
    }
}
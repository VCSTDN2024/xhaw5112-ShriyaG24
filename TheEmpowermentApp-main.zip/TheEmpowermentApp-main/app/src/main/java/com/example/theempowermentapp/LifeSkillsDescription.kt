package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LifeSkillsDescription : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_life_skills_description)
        val nextButton: Button = findViewById(R.id.nxtBtn3)
        nextButton.setOnClickListener {
            val intent = Intent(this, ChildMindingDescription::class.java)
            startActivity(intent)
        }
        val courseSelectionButton: Button = findViewById(R.id.backtoselectionBtn5)
        courseSelectionButton.setOnClickListener {
            val intent = Intent(this, CourseSelection::class.java)
            startActivity(intent)
        }
    }
}
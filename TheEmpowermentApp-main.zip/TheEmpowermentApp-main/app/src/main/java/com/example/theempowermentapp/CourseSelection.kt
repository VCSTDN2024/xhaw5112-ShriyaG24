package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CourseSelection : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_course_selection)
        val monthButton: Button = findViewById(R.id.monthcourseBtn)
        monthButton.setOnClickListener {
            val intent = Intent(this, SixMonthCourses::class.java)
            startActivity(intent)
        }
        val weekButton: Button = findViewById(R.id.weekcourseBtn)
        weekButton.setOnClickListener {
            val intent = Intent(this, SixWeekCourses::class.java)
            startActivity(intent)
        }
        val backButton: Button = findViewById(R.id.backBtn2)
        backButton.setOnClickListener {
            val intent = Intent(this, Information::class.java)
            startActivity(intent)
        }
        val courseSelectionButton: Button = findViewById(R.id.selectionBtn2)
        courseSelectionButton.setOnClickListener {
            val intent = Intent(this, CourseSelection::class.java)
            startActivity(intent)
        }
        val selectionButton: Button = findViewById(R.id.selectionBtn2)
        selectionButton.setOnClickListener {
            val intent = Intent(this, Selection::class.java)
            startActivity(intent)
        }
    }
}

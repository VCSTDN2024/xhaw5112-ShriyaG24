package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Checkout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_checkout)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val backButton: Button = findViewById(R.id.backBtn5)
        backButton.setOnClickListener {
            val intent = Intent(this, Selection::class.java)
            startActivity(intent)
        }

        val getInTouchButton: Button = findViewById(R.id.getInTouchBtn)
        getInTouchButton.setOnClickListener {
            val intent = Intent(this, GetInTouch::class.java)
            startActivity(intent)
        }

        // Get the selected courses from the intent
        val firstAid = intent.getBooleanExtra("firstAid", false)
        val sewing = intent.getBooleanExtra("sewing", false)
        val landscaping = intent.getBooleanExtra("landscaping", false)
        val lifeSkills = intent.getBooleanExtra("lifeSkills", false)
        val childMinding = intent.getBooleanExtra("childMinding", false)
        val cooking = intent.getBooleanExtra("cooking", false)
        val gardenMaintenance = intent.getBooleanExtra("gardenMaintenance", false)

        // Calculate the number of selected courses and the total amount
        val selectedCourses = listOf(
            firstAid,
            sewing,
            landscaping,
            lifeSkills,
            childMinding,
            cooking,
            gardenMaintenance
        )
        val checkedCount = selectedCourses.count { it }  // Count the number of selected courses

        val (finalAmount, discountPercentage) = calculateAmount(
            firstAid,
            sewing,
            landscaping,
            lifeSkills,
            childMinding,
            cooking,
            gardenMaintenance,
            checkedCount
        )

        // Set the values on the TextViews
        val numberOfCoursesTextView: TextView = findViewById(R.id.textView)
        val totalAmountTextView: TextView = findViewById(R.id.amountTextView)
        val discountAppliedTextView: TextView = findViewById(R.id.discountTextView)

        numberOfCoursesTextView.text = "Number of courses chosen: $checkedCount"
        totalAmountTextView.text = "Total amount: R${String.format("%.2f", finalAmount)}"
        discountAppliedTextView.text = "Discount applied: $discountPercentage%"

        // Send invoice via email when button is clicked
        val sendInvoiceButton: Button = findViewById(R.id.sendInvoice)
        sendInvoiceButton.setOnClickListener {
            // Get user input for name and phone number
            val nameEditText: EditText = findViewById(R.id.editTextText)
            val phoneEditText: EditText = findViewById(R.id.editTextText2)
            val userName = nameEditText.text.toString()
            val phoneNumber = phoneEditText.text.toString()

            sendInvoice(
                finalAmount, checkedCount, userName, phoneNumber,
                firstAid, sewing, landscaping, lifeSkills, childMinding, cooking, gardenMaintenance
            )
        }
    }

    private fun calculateAmount(
        firstAid: Boolean, sewing: Boolean, landscaping: Boolean,
        lifeSkills: Boolean, childMinding: Boolean, cooking: Boolean, gardenMaintenance: Boolean,
        checkedCount: Int
    ): Pair<Double, Int> {
        // Course prices
        val firstAidPrice = 1500.0
        val sewingPrice = 1500.0
        val landscapingPrice = 1500.0
        val lifeSkillsPrice = 1500.0
        val childMindingPrice = 750.0
        val cookingPrice = 750.0
        val gardenMaintenancePrice = 750.0

        // Calculate total price based on selected courses
        var amount = 0.0
        if (firstAid) amount += firstAidPrice
        if (sewing) amount += sewingPrice
        if (landscaping) amount += landscapingPrice
        if (lifeSkills) amount += lifeSkillsPrice
        if (childMinding) amount += childMindingPrice
        if (cooking) amount += cookingPrice
        if (gardenMaintenance) amount += gardenMaintenancePrice

        // Apply discount based on the number of selected courses
        var discountPercentage = 0
        when (checkedCount) {
            1 -> discountPercentage = 0
            2 -> discountPercentage = 5
            3 -> discountPercentage = 10
            in 4..7 -> discountPercentage = 15
        }

        val discount = (amount * discountPercentage) / 100
        val amountAfterDiscount = amount - discount

        // Apply VAT (15%)
        val vatPercentage = 15
        val vat = (amountAfterDiscount * vatPercentage) / 100
        val finalAmount = amountAfterDiscount + vat

        // Replace comma with period for proper parsing
        val roundedFinalAmount = String.format("%.2f", finalAmount).replace(",", ".")

        // Convert the result to a double
        return Pair(roundedFinalAmount.toDouble(), discountPercentage)
    }

    private fun sendInvoice(
        totalAmount: Double, numberOfCourses: Int, userName: String, phoneNumber: String,
        firstAid: Boolean, sewing: Boolean, landscaping: Boolean, lifeSkills: Boolean,
        childMinding: Boolean, cooking: Boolean, gardenMaintenance: Boolean
    ) {
        val subject = "Invoice for Your Course Selection and total"
        val recipient = "sukramashish@gmail.com"

        // Build the selected courses list with their prices
        val selectedCoursesDetails = StringBuilder()
        if (firstAid) selectedCoursesDetails.append("First Aid: R1500.00\n")
        if (sewing) selectedCoursesDetails.append("Sewing: R1500.00\n")
        if (landscaping) selectedCoursesDetails.append("Landscaping: R1500.00\n")
        if (lifeSkills) selectedCoursesDetails.append("Life Skills: R1500.00\n")
        if (childMinding) selectedCoursesDetails.append("Child Minding: R750.00\n")
        if (cooking) selectedCoursesDetails.append("Cooking: R750.00\n")
        if (gardenMaintenance) selectedCoursesDetails.append("Garden Maintenance: R750.00\n")

        // Build the email message
        val message = """
        Good day, $userName,

        Thank you for selecting your courses. Here is a summary of your invoice:
        
        Phone: $phoneNumber
        Number of courses selected: $numberOfCourses

        Selected Courses:
        $selectedCoursesDetails

        Total amount (including VAT): R$totalAmount
        

        Please make the payment at your earliest convenience.

        Best regards,
        The Empowerment Team
    """.trim()  // Use trim() to remove leading and trailing whitespace

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, message)
        }

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(Intent.createChooser(intent, "Send Invoice"))
        }
    }
}

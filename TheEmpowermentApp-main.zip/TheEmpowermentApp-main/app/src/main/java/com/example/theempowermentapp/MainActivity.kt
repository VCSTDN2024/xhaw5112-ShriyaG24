package com.example.theempowermentapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val exitButton: Button = findViewById(R.id.exitBtn)
        exitButton.setOnClickListener {
            finishAffinity()
        }

        val proceedButton: Button = findViewById(R.id.proceedBtn)
        proceedButton.setOnClickListener {
            val intent = Intent(this, Information::class.java)
            startActivity(intent)
        }
        val getInTouchButton: Button = findViewById(R.id.getInTouchBtn2)
        getInTouchButton.setOnClickListener {
            val intent = Intent(this, GetInTouch::class.java)
            startActivity(intent)
        }
    }
}
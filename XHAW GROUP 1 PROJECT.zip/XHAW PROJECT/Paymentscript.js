document.getElementById('calculate-fee').addEventListener('click', function() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    let total = 0;

    checkboxes.forEach(checkbox => {
        const fee = parseFloat(checkbox.getAttribute('data-fee'));
        total += fee;
    });

    // Apply discounts based on the number of selected courses
    let discount = 0;
    if (checkboxes.length === 2) {
        discount = 0.05;
    } else if (checkboxes.length === 3) {
        discount = 0.10;
    } else if (checkboxes.length > 3) {
        discount = 0.15;
    }

    total -= total * discount;

    // Add VAT (15%)
    const vat = total * 0.15;
    total += vat;

    // Update the total fee on the page
    document.getElementById('total-fee').innerText = `R${total.toFixed(2)}`;
});

document.getElementById('send-invoice').addEventListener('click', function() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    const selectedCourses = [];

    checkboxes.forEach(checkbox => {
        const course = checkbox.value;
        const fee = parseFloat(checkbox.getAttribute('data-fee'));
        selectedCourses.push({ course, fee });
    });

    if (!name || !email || !phone || selectedCourses.length === 0) {
        document.getElementById('error-message').innerText = 'Please fill all fields and select at least one course.';
        document.getElementById('error-message').style.display = 'block';
        return;
    } else {
        document.getElementById('error-message').style.display = 'none';
    }

    const total = document.getElementById('total-fee').innerText.replace('R', '');

    // Prepare email content
    let emailBody = `Good day ${name},\n\nThank you for registering for our courses. Here is a summary of your invoice:\n\n`;
    emailBody += `Phone: ${phone}\nNumber of Selected Courses: ${selectedCourses.length}\n\nSelected Courses:\n`;
    selectedCourses.forEach(course => {
        emailBody += `${course.course}: R${course.fee.toFixed(2)}\n`;
    });
    emailBody += `\nTotal Amount (including VAT): R${total}\n\nPlease make the payment at your earliest convenience.\n\nBest regards,\nThe Empowerment Team`;

    // Create mailto link
    const mailtoLink = `mailto:${email}?subject=Course Registration Invoice&body=${encodeURIComponent(emailBody)}`;

    // Open email client with pre-filled invoice details
    window.location.href = mailtoLink;
});

// Display the toast message
document.getElementById('callbackForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById('toast').classList.add('show');
    setTimeout(function() {
        document.getElementById('toast').classList.remove('show');
    }, 3000); // Hide toast after 3 seconds
});
